from YesapiClient import callApi, example_get_request, example_post_request

# 调用 GET 接口
example_get_request(choice1="剪刀", decrypt=False)

# 调用 POST 接口
example_post_request(guess1="1", guess2="2", guess3="3", decrypt=False)