import requests
from typing import Optional, Dict, Any
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from tenacity import Retrying, stop_after_attempt, wait_fixed, retry_if_exception_type

API_URL = "https://api.example.com"
APP_KEY = "your-app-key"
APP_SECRET = "your-secret-key"
AES_KEY = "your-aes-key"

class YesapiClient:
    def __init__(self, api_url: str, aes_key: Optional[str] = None):
        """
        初始化SDK
        :param api_url: API 的基础地址
        :param aes_key: AES 密钥（用于请求加密 & 响应解密）
        """
        self.api_url = api_url
        self._headers = {}
        self.aes_key = aes_key  # 新增：AES 密钥
        self.enable_response_decrypt = False  # 响应数据解密开关
        self.retry_times = 3
        self.retry_wait = 1

    def AuthApplyToken(self, app_key: str, app_secret: str) -> str:
        """
        申请令牌 Token（实际调用接口获取 token）
        """
        apply_token_url = self.api_url + "/api/official/auth/apply_token"
        data = {
            "app_key": app_key,
            "app_secret": app_secret
        }
        response = requests.post(apply_token_url, json=data, timeout=10)
        result = response.json()
        # 获取token
        return result.get("data", {}).get("access_token", "")

    def header(self, headers: Dict[str, str]) -> 'YesAPISDKRequest':
        """
        设置请求头
        """
        self._headers = headers
        return Request(self)

    def enable_decrypt(self, enable: bool = True) -> 'YesAPISDK':
        self.enable_response_decrypt = enable
        return self

    def _aes_decrypt(self, encrypted_data: str) -> str:
        if not self.aes_key:
            raise ValueError("AES key 未设置，无法解密。")

        # 将十六进制字符串转为 bytes
        encrypted_bytes = bytes.fromhex(encrypted_data)

        if len(encrypted_bytes) % AES.block_size != 0:
            raise ValueError(f"加密数据长度不合法，必须是 {AES.block_size} 的倍数")

        # 使用 CBC 模式，且 IV == Key
        cipher = AES.new(self.aes_key.encode('utf-8'), AES.MODE_CBC, iv=self.aes_key.encode('utf-8'))
        decrypted = cipher.decrypt(encrypted_bytes)

        return unpad(decrypted, AES.block_size).decode('utf-8')

    def set_retry(self, times: int = 3, wait: int = 1):
        """
        设置请求失败时的最大重试次数和间隔时间
        :param times: 最大重试次数
        :param wait: 每次失败后等待的秒数
        """
        self.retry_times = times
        self.retry_wait = wait
        return self


class Request:
    def __init__(self, client: YesapiClient):
        self.client = client

    def get(self, path: str, params: Optional[Dict[str, Any]] = None, timeout: int = 10) -> Dict[str, Any]:
        for attempt in Retrying(
            stop=stop_after_attempt(self.client.retry_times),
            wait=wait_fixed(self.client.retry_wait),
            retry=retry_if_exception_type((requests.exceptions.RequestException,))
        ):
            with attempt:
                url = self.client.api_url + path
                response = requests.get(url, headers=self.client._headers, params=params, timeout=timeout)
                result = response.json()

                if self.client.enable_response_decrypt and 'data' in result:
                    try:
                        result['data'] = self.client._aes_decrypt(result['data'])
                    except Exception as e:
                        print(f"解密失败: {e}")

                return result

    def post(self, path: str, data: Dict[str, Any], timeout: int = 10) -> Dict[str, Any]:
        for attempt in Retrying(
            stop=stop_after_attempt(self.client.retry_times),
            wait=wait_fixed(self.client.retry_wait),
            retry=retry_if_exception_type((requests.exceptions.RequestException,))
        ):
            with attempt:
                url = self.client.api_url + path
                response = requests.post(url, json=data, headers=self.client._headers, timeout=timeout)
                result = response.json()

                if self.client.enable_response_decrypt and 'data' in result:
                    try:
                        result['data'] = self.client._aes_decrypt(result['data'])
                    except Exception as e:
                        print(f"解密失败: {e}")

                return result

def callApi(
    route: str,
    method: str = "GET",
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Dict[str, Any]] = None,
    decrypt: bool = False,   # 是否启用响应解密
    timeout: int = 5,
    retry_times: int = 3,   # 设置请求失败时最大的重试次数
    retry_wait: int = 1   # 响应失败时每次等待的秒数
) -> Dict[str, Any]:
    # 初始化客户端并设置 AES 加解密（如果提供了 aes_key）
    client = YesapiClient(API_URL, aes_key=AES_KEY)
    client.set_retry(retry_times, retry_wait)

    # AES解密
    if decrypt and AES_KEY:
        client.enable_decrypt(True)
    else:
        client.enable_decrypt(False)

    # 获取 Token
    token = client.AuthApplyToken(APP_KEY, APP_SECRET)

    # 设置请求头并获取请求对象
    request = client.header({
        'access-token': token
    })

    # 根据请求方法调用相应的接口
    if method.upper() == "GET":
        result = request.get(route, params=params, timeout=timeout)
    elif method.upper() == "POST":
        result = request.post(route, data=data or {}, timeout=timeout)
    else:
        raise ValueError("不支持的 HTTP 方法")

    return result

# 示例：调用 GET 请求
def example_get_request(choice1=None, decrypt: bool = False):
    result_get = callApi(
        route='/online-api/v1/get_sdk/test',
        method='GET',
        params={'choice1': choice1},
        decrypt=decrypt,
        timeout=10,
        retry_times=3,
        retry_wait=1
    )
    print(result_get)
    return result_get


# 示例：调用 POST 请求
def example_post_request(guess1=None, guess2=None, guess3=None, decrypt: bool = False):
    result_post = callApi(
        route='/online-api/v1/post_sdk/test',
        method='POST',
        data={'guess1': guess1, 'guess2': guess2, 'guess3': guess3},
        decrypt=decrypt,
        timeout=10,
        retry_times=3,
        retry_wait=1
    )
    print(result_post)
    return result_post


# 可选：主入口用于测试时手动调用
if __name__ == "__main__":
    # 调用 GET 接口
    example_get_request(choice1="剪刀", decrypt=True)

    # 调用 POST 接口
    example_post_request(guess2="2", guess3="3", decrypt=False)