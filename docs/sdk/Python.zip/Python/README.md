# YesAPI Python SDK

这是 YesAPI 的 Python 版本 SDK，提供了与服务端 API 交互的简单方式。

## 功能特点
- 支持链式调用（Fluent Interface）
- 提供 GET 和 POST 请求能力
- 支持响应数据 AES 解密
- 支持请求头设置
- 支持超时时间设置
- 支持请求失败自动重试
- 支持自定义重试次数和等待时间
- 支持访问令牌自动申请

## 环境要求
- Python 3.7 或更高版本

- 依赖库：
  - requests
  - pycryptodome
  - tenacity

## 安装
1. 克隆代码到本地
2. 进入项目目录
3. 你可以通过以下命令安装依赖：
```bash
pip install requests pycryptodome tenacity
```

## 使用示例

### 初始化 SDK 并调用接口

```python
from YesapiClient import example_get_request, example_post_request

# 调用 GET 接口并启用解密
example_get_request(choice1="剪刀", decrypt=True)

# 调用 POST 接口，不启用解密
example_post_request(guess2="2", guess3="3", decrypt=False)
```

### 自定义调用接口

```python
from YesapiClient import callApi

result = callApi(
  route="/online-api/v1/get_sdk/test",
  method="GET",
  params={"choice1": "石头"},
  decrypt=True,
  timeout=10
)
print("接口响应：", result)
```

## 主要类和方法说明

### YesAPISDK
SDK 核心类，用于配置 API 地址、AES 密钥、Token 获取等。

### 构造函数
```python
def __init__(self, api_url: str, aes_key: Optional[str] = None)
```

### 方法
| 方法                                  | 描述 |
|-------------------------------------|------|
| AuthApplyToken(app_key, app_secret) |获取访问令牌|
| header(headers)                     |设置请求头|
| enable_decrypt(enable)              |启用响应数据 AES 解密|
|set_retry(times=3, wait=1)|设置请求失败自动重试次数和等待时间|

### YesAPISDKRequest
| 方法                                  | 描述 |
|-------------------------------------|------|
|get(path, params=None, timeout=10)|发起 GET 请求|
|post(path, data=None, timeout=10)|发起 POST 请求|

### callApi()
| 参数 | 类型 | 默认值 | 描述 | 
|------|------|--------|------|
| route | str | 必填 | 接口路径 |
| method | str | "GET" | 请求方法（GET/POST） |
| params | dict | None | GET 请求参数 |
| data | dict | None | POST 请求体 |
| decrypt | bool | False | 是否启用响应解密 |
| timeout | int | 5 | 请求超时时间（秒） |
| retry_times | int | 3 | 请求失败自动重试次数 |
| retry_wait | int | 1 | 请求失败自动重试等待时间（秒） |

## 注意事项
1. 修改 APP_KEY, APP_SECRET, AES_KEY 为你自己的应用密钥。
2. 建议在生产环境中合理设置 timeout 和增加重试机制。
3. 所有接口调用前都会自动获取 Token，无需手动刷新。
4. 示例函数仅用于测试，实际使用请根据业务需求封装。