package main

import (
	"fmt"
	"log"

	"Golang/YesapiClient"
)

func main() {
	// 示例 GET 请求，并启用解密
	getResult, getErr := YesapiClient.ExampleGetRequest("剪刀", false)
	if getErr != nil {
		log.Fatalf("GET 请求失败: %v", getErr)
	}
	fmt.Printf("GET 响应数据: %+v\n", getResult)

	// 示例 POST 请求，并启用解密
	result, err := YesapiClient.ExamplePostRequest("1", "2", nil, false)
	if err != nil {
		log.Fatalf("POST 请求失败: %v", err)
	}
	fmt.Printf("POST 响应数据: %+v\n", result)
}
