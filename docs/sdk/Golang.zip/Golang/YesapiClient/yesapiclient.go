package YesapiClient

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// 配置信息
const (
	API_URL    = "https://api.example.com" // 设置请求路径
	APP_KEY    = "your-app-key" // 应用key
	APP_SECRET = "your-secret-key" // 应用密钥
	AES_KEY    = "your-aes-key" // 加密密钥
)

// Client 是YesAPI的客户端
type Client struct {
	APIURL        string
	headers       map[string]string
	aesKey        []byte
	enableDecrypt bool
	retryTimes    int           // 最大重试次数
	retryWait     time.Duration // 每次失败后等待时间
	timeout       time.Duration // 请求超时时间
}

// Request 是YesAPI的请求对象
type Request struct {
	client *Client
}

// TokenResponse 表示申请令牌的响应结构
type TokenResponse struct {
	Data struct {
		AccessToken string `json:"access_token"`
	} `json:"data"`
}

// APIRequest 统一请求参数结构体
type APIRequest struct {
	Route  string
	Params map[string]interface{} // GET 参数
	Data   map[string]interface{} // POST 数据
	Method string                 // "GET" 或 "POST"
}

// NewClient 创建一个新的YesAPI客户端
func NewClient(apiURL string) *Client {
	if apiURL == "" {
		apiURL = API_URL
	}
	return &Client{
		APIURL:  apiURL,
		headers: make(map[string]string),
	}
}

// _aesDecrypt 解密十六进制字符串数据
func (c *Client) _aesDecrypt(encryptedData string) (string, error) {
	key := []byte(AES_KEY)

	// 将十六进制字符串转为字节切片
	encryptedBytes, err := hex.DecodeString(encryptedData)
	if err != nil {
		return "", fmt.Errorf("十六进制解码失败: %w", err)
	}

	if len(encryptedBytes)%aes.BlockSize != 0 {
		return "", fmt.Errorf("加密数据长度不合法，必须是 %d 的倍数", aes.BlockSize)
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", fmt.Errorf("创建 AES cipher 失败: %w", err)
	}

	mode := cipher.NewCBCDecrypter(block, key[:aes.BlockSize])
	decrypted := make([]byte, len(encryptedBytes))
	mode.CryptBlocks(decrypted, encryptedBytes)

	// 去除 PKCS7 填充
	unpadded, err := pkcs7Unpad(decrypted, aes.BlockSize)
	if err != nil {
		return "", fmt.Errorf("去除填充失败: %w", err)
	}

	return string(unpadded), nil
}

func pkcs7Unpad(data []byte, blockSize int) ([]byte, error) {
	length := len(data)
	if length == 0 {
		return nil, fmt.Errorf("数据为空")
	}
	padding := int(data[length-1])
	if padding > blockSize || padding == 0 {
		return nil, fmt.Errorf("无效的填充")
	}
	for i := length - padding; i < length; i++ {
		if data[i] != byte(padding) {
			return nil, fmt.Errorf("填充格式错误")
		}
	}
	return data[:length-padding], nil
}

// EnableDecrypt 设置是否启用响应解密
func (c *Client) EnableDecrypt(enable bool) *Client {
	c.enableDecrypt = enable
	return c
}

// SetTimeout 设置请求超时时间
func (c *Client) SetTimeout(timeout time.Duration) *Client {
	c.timeout = timeout
	return c
}

// SetRetry 设置最大重试次数和每次等待时间
func (c *Client) SetRetry(times int, wait time.Duration) *Client {
	c.retryTimes = times
	c.retryWait = wait
	return c
}

// AuthApplyToken 申请令牌Token（实际调用接口获取token）
func (c *Client) AuthApplyToken(appKey, appSecret string) (string, error) {
	applyTokenURL := c.APIURL + "/api/official/auth/apply_token"

	data := map[string]string{
		"app_key":    appKey,
		"app_secret": appSecret,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		return "", fmt.Errorf("序列化请求数据失败: %w", err)
	}

	req, err := http.NewRequest("POST", applyTokenURL, bytes.NewBuffer(jsonData))
	if err != nil {
		return "", fmt.Errorf("创建请求失败: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("发送请求失败: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("读取响应内容失败: %w", err)
	}

	var tokenResp TokenResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return "", fmt.Errorf("解析响应失败: %w", err)
	}

	return tokenResp.Data.AccessToken, nil
}

// SetHeader 设置请求头
func (c *Client) SetHeader(headers map[string]string) *Request {
	c.headers = headers
	return &Request{client: c}
}

// Get 发起GET请求
func (r *Request) Get(path string, params map[string]interface{}) (map[string]interface{}, error) {
	var result map[string]interface{}

	url := r.client.APIURL + path

	for attempt := 0; attempt <= r.client.retryTimes; attempt++ {
		if attempt > 0 {
			time.Sleep(r.client.retryWait * time.Second)
		}

		req, reqErr := http.NewRequest("GET", url, nil)
		if reqErr != nil {
			return nil, fmt.Errorf("创建GET请求失败: %w", reqErr)
		}

		// 设置请求头
		for key, value := range r.client.headers {
			req.Header.Set(key, value)
		}

		// 设置查询参数
		if params != nil {
			q := req.URL.Query()
			for key, value := range params {
				q.Add(key, fmt.Sprintf("%v", value))
			}
			req.URL.RawQuery = q.Encode()
		}

		httpClient := &http.Client{
			Timeout: r.client.timeout * time.Second,
		}

		resp, doErr := httpClient.Do(req)
		if doErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("发送GET请求失败: %w", doErr)
		}
		defer resp.Body.Close()

		body, readErr := io.ReadAll(resp.Body)
		if readErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("读取GET响应内容失败: %w", readErr)
		}

		unmarshalErr := json.Unmarshal(body, &result)
		if unmarshalErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("解析GET响应失败: %w", unmarshalErr)
		}

		break
	}

	// 如果启用了解密，并且返回中有 data 字段
	if r.client.enableDecrypt && result["data"] != nil {
		dataStr, ok := result["data"].(string)
		if !ok {
			fmt.Println("警告: data字段不是字符串，无法解密，将使用原始数据")
		} else {
			decryptedData, decryptErr := r.client._aesDecrypt(dataStr)
			if decryptErr != nil {
				fmt.Printf("解密失败: %v\n", decryptErr)
			} else {
				result["data"] = decryptedData
			}
		}
	}

	return result, nil
}

// Post 发起POST请求
func (r *Request) Post(path string, data map[string]interface{}) (map[string]interface{}, error) {
	var result map[string]interface{}

	url := r.client.APIURL + path

	jsonData, marshalErr := json.Marshal(data)
	if marshalErr != nil {
		return nil, fmt.Errorf("序列化POST数据失败: %w", marshalErr)
	}

	for attempt := 0; attempt <= r.client.retryTimes; attempt++ {
		if attempt > 0 {
			time.Sleep(r.client.retryWait * time.Second)
		}

		req, reqErr := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
		if reqErr != nil {
			return nil, fmt.Errorf("创建POST请求失败: %w", reqErr)
		}

		// 设置请求头
		req.Header.Set("Content-Type", "application/json")
		for key, value := range r.client.headers {
			req.Header.Set(key, value)
		}

		httpClient := &http.Client{
			Timeout: r.client.timeout * time.Second,
		}

		resp, doErr := httpClient.Do(req)
		if doErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("发送POST请求失败: %w", doErr)
		}
		defer resp.Body.Close()

		body, readErr := io.ReadAll(resp.Body)
		if readErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("读取POST响应内容失败: %w", readErr)
		}

		unmarshalErr := json.Unmarshal(body, &result)
		if unmarshalErr != nil {
			if attempt < r.client.retryTimes {
				continue
			}
			return nil, fmt.Errorf("解析POST响应失败: %w", unmarshalErr)
		}

		break
	}

	// 如果启用了解密，并且返回中有 data 字段
	if r.client.enableDecrypt && result["data"] != nil {
		dataStr, ok := result["data"].(string)
		if !ok {
			fmt.Println("警告: data字段不是字符串，无法解密，将使用原始数据")
		} else {
			decryptedData, decryptErr := r.client._aesDecrypt(dataStr)
			if decryptErr != nil {
				fmt.Printf("解密失败: %v\n", decryptErr)
			} else {
				result["data"] = decryptedData
			}
		}
	}

	return result, nil
}

// CallAPI ，用于调用API
func CallAPI(req APIRequest, decrypt bool, timeout time.Duration, retryTimes int, retryWait time.Duration) (map[string]interface{}, error) {
	// 初始化客户端
	client := NewClient(API_URL)

	// AES解密
	if decrypt {
		client.EnableDecrypt(true)
	}

	// 获取Token
	token, err := client.AuthApplyToken(APP_KEY, APP_SECRET)
	if err != nil {
		return nil, fmt.Errorf("获取Token失败: %w", err)
	}

	// 设置请求头
	headers := map[string]string{
		"access-token": token,
	}

	// 根据请求方法调用接口
	switch req.Method {
	case "GET":
		return client.SetHeader(headers).Get(req.Route, req.Params)
	case "POST":
		if req.Data == nil {
			req.Data = make(map[string]interface{})
		}
		return client.SetHeader(headers).Post(req.Route, req.Data)
	default:
		return nil, fmt.Errorf("不支持的HTTP方法: %s", req.Method)
	}
}

// ExampleGetRequest 示例：调用GET请求
func ExampleGetRequest(choice1 string, decrypt bool) (map[string]interface{}, error) {
	result, err := CallAPI(APIRequest{
		Route: "/online-api/v1/get_sdk/test",
		Params: map[string]interface{}{
			"choice1": choice1,
		},
		Method: "GET",
	}, decrypt, 10*time.Second, 3, 1*time.Second)
	if err != nil {
		return nil, fmt.Errorf("调用GET接口失败: %w", err)
	}

	return result, nil
}

// ExamplePostRequest 示例：调用POST请求
func ExamplePostRequest(guess1, guess2, guess3 interface{}, decrypt bool) (map[string]interface{}, error) {
	data := map[string]interface{}{}
	if guess1 != nil {
		data["guess1"] = guess1
	}
	if guess2 != nil {
		data["guess2"] = guess2
	}
	if guess3 != nil {
		data["guess3"] = guess3
	}

	result, err := CallAPI(APIRequest{
		Route:  "/online-api/v1/post_sdk/test",
		Data:   data,
		Method: "POST",
	}, decrypt, 10*time.Second, 3, 1*time.Second)
	if err != nil {
		return nil, fmt.Errorf("调用POST接口失败: %w", err)
	}

	return result, nil
}
