# YesAPI Python SDK

这是 YesAPI 的 Go 语言版本 SDK，提供了与服务端 API 交互的简单方式。

## 功能特点
- 支持链式调用（Fluent Interface）
- 提供 GET 和 POST 请求能力
- 支持响应数据 AES 解密
- 支持请求头设置
- 支持超时时间设置
- 支持请求失败自动重试
- 支持自定义重试次数和等待时间
- 支持访问令牌自动申请

## 环境要求
- Go 1.18 或更高版本

## 安装
1. 克隆代码到本地
2. 进入项目目录
3. 创建一个名为Golang的模块（在项目主目录Golang运行一下命令，可自定义）：
```bash
go mod init Golang
```

## 使用示例

### 初始化 SDK 并调用接口

```Go
result, err := ExampleGetRequest("剪刀", true)
if err != nil {
    log.Fatalf("GET 请求失败: %v", err)
}
fmt.Printf("GET 响应结果: %v\n", result)

result, err = ExamplePostRequest("1", "2", "3", false)
if err != nil {
    log.Fatalf("POST 请求失败: %v", err)
}
fmt.Printf("POST 响应结果: %v\n", result)
```

### 自定义调用接口

```Go
req := yesapi_sdk.APIRequest{
    Route: "/online-api/v1/get_sdk/test",
    Params: map[string]interface{}{
        "choice1": "石头",
    },
    Method: "GET",
}

result, err := yesapi_sdk.CallAPI(req, true, 10*time.Second, 3, 1*time.Second)
if err != nil {
    log.Fatalf("调用接口失败: %v", err)
}
fmt.Printf("接口响应：%v\n", result)
```

## 主要类和方法说明

### Client
SDK 核心类，用于配置 API 地址、AES 密钥、Token 获取等。

### 构造函数
```Go
func NewClient(apiURL string) *Client
```

### 方法
| 方法                                  | 描述 |
|-------------------------------------|------|
| AuthApplyToken(appKey, appSecret string) (string, error) |获取访问令牌|
| EnableDecrypt(enable bool) *Client              |启用或禁用响应数据 AES 解密|
|SetTimeout(timeout time.Duration) *Client|设置请求超时时间|
| SetRetry(times int, wait time.Duration) *Client |设置请求失败自动重试次数和等待时间|

### Request
| 方法                                  | 描述 |
|-------------------------------------|------|
|Get(path string, params map[string]interface{}) (map[string]interface{}, error)|发起 GET 请求|
|Post(path string, data map[string]interface{}) (map[string]interface{}, error)|发起 POST 请求|

### CallAPI
| 参数 | 类型 | 默认值 | 描述 | 
|------|------|--------|------|
| req | APIRequest | 必填 | 接口请求结构体 |
| decrypt | bool | False | 是否启用响应解密 |
| timeout | time.Duration | 10s | 请求超时时间（秒） |
| retryTimes | int | 3 | 请求失败自动重试次数 |
| retryWait | time.Duration | 1s | 请求失败自动重试等待时间（秒） |

## 注意事项
1. 修改 APP_KEY, APP_SECRET, AES_KEY 为你自己的应用密钥。
2. 建议在生产环境中合理设置 timeout 和增加重试机制。
3. 所有接口调用前都会自动获取 Token，无需手动刷新。
4. 示例函数仅用于测试，实际使用请根据业务需求封装。