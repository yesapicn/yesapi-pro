# YesapiClient PHP SDK

YesapiClient 是一个用于简化 API 调用的 PHP 客户端库，提供了丰富的功能和灵活的配置选项。

## 特性

- 链式调用 API，简洁易用
- 支持 GET 和 POST 请求
- 自动 Token 认证和刷新
- 参数加密和结果解密功能
- 自动重试机制
- 超时控制
- 自定义请求头

## 安装

将 `YesapiClient.php` 文件复制到您的项目中，然后通过 `require` 或 `include` 引入：

```php
require_once 'path/to/YesapiClient.php';
```

## 基本用法

### 创建客户端实例

```php
$client = new YesapiClient(
    'https://api.example.com',  // API域名
    'your-encrypt-key',         // 加密密钥
    'your-app-key',             // 应用key
    'your-app-secret'           // 应用密钥
);
```

### 发送 GET 请求

```php
$result = $client
    ->path('api/user/list')
    ->params([
        'page' => 1,
        'limit' => 10
    ])
    ->get();
```

### 发送 POST 请求

```php
$result = $client
    ->path('api/user/create')
    ->params([
        'token' => 'session-token'  // URL查询参数
    ])
    ->body([
        'username' => 'testuser',   // POST请求体参数
        'email' => 'test@example.com'
    ])
    ->post();
```

## Token 认证

YesapiClient 支持自动的 token 认证机制。当创建客户端实例时，可以选择是否自动初始化 token：

```php
// 创建客户端实例并自动初始化token（默认行为）
$client = new YesapiClient(
    'https://api.example.com',
    'your-encrypt-key',
    'your-app-key',
    'your-app-secret',
    true  // 自动初始化token
);

// 或者禁用自动初始化token
$client = new YesapiClient(
    'https://api.example.com',
    'your-encrypt-key',
    'your-app-key',
    'your-app-secret',
    false  // 不自动初始化token
);

// 手动初始化token
try {
    $client->initToken();
} catch (Exception $e) {
    echo "Token初始化失败: " . $e->getMessage();
}
```

### Token 自动管理

YesapiClient 提供了以下 token 相关的自动化功能：

1. **自动获取**: 在创建实例时自动获取 token（可配置）
2. **自动添加**: 每个请求自动添加 token 到请求头
3. **自动刷新**: 检测到 token 过期时自动刷新
4. **自动重试**: token 失效时自动重新获取并重试请求

### 使用示例

```php
// token会自动添加到请求头中
try {
    $result = $client
        ->path('api/protected/resource')
        ->params(['id' => 123])
        ->get();
    
    print_r($result);
} catch (Exception $e) {
    echo "请求失败: " . $e->getMessage();
}

// token过期会自动刷新
try {
    $result = $client
        ->path('api/protected/data')
        ->body(['action' => 'update'])
        ->post();
    
    print_r($result);
} catch (Exception $e) {
    echo "请求失败: " . $e->getMessage();
}
```

## 高级功能

### 请求重试

设置请求失败时的重试次数：

```php
$client->retry(3);  // 最多重试3次
```

### 超时控制

设置请求超时时间（秒）：

```php
$client->timeout(5);  // 5秒超时
```

### 自定义请求头

添加自定义 HTTP 请求头：

```php
$client->headers([
    'Authorization: Bearer token123',
    'X-Custom-Header: value'
]);
```

### 参数加密

启用请求参数加密（仅对 POST 请求体有效）：

```php
$client->enableParamEncrypt(true);
```

启用参数加密后，整个 POST 请求体会被加密为一个字符串，而不是 JSON 对象。服务器端需要先解密这个字符串，然后再处理请求参数。

### 响应解密

启用响应结果解密（针对 data 字段）：

```php
$client->enableResponseDecrypt(true);
```

## 完整示例

```php
try {
    $result = $client
        ->path('api/secure/data')
        ->params(['token' => 'secure-token'])
        ->body(['sensitive_data' => 'confidential information'])
        ->timeout(10)
        ->retry(2)
        ->headers(['X-API-Version: 2.0'])
        ->enableParamEncrypt(true)
        ->enableResponseDecrypt(true)
        ->post();
    
    print_r($result);
} catch (Exception $e) {
    echo "请求失败: " . $e->getMessage();
}
```

## 错误处理

YesapiClient 使用 PHP 异常机制处理错误。所有请求都应该放在 try-catch 块中：

```php
try {
    $result = $client->path('api/endpoint')->get();
} catch (Exception $e) {
    echo "错误: " . $e->getMessage();
}
```

## 加密说明

YesapiClient 使用 AES-128-CBC 加密算法，加密密钥同时用作 IV。加密仅应用于 POST 请求体，而不是 URL 查询参数。

当启用参数加密时：
1. 客户端会将整个 POST 请求体（JSON 格式）转换为字符串
2. 使用 AES-128-CBC 算法和提供的加密密钥对该字符串进行加密
3. 将加密后的字符串直接作为请求体发送，而不是包装在 JSON 对象中
4. 服务器端需要先解密这个字符串，然后再解析为 JSON 并处理请求参数

这种方式确保了敏感数据在传输过程中的安全性，因为整个请求体都是加密的。

## 注意事项

- 每次请求后，参数会自动重置，不会影响下一次请求
- 加密密钥长度应为16字节，如果长度不足会自动填充，如果超出会被截断
- 请确保服务器端使用相同的加密算法和密钥
