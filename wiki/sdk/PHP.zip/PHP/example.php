<?php

require_once 'YesapiClient.php';

// 创建客户端实例 - 自动初始化token
$client = new YesapiClient(
    'https://api.example.com',  // API域名
    'your-encrypt-key',         // 加密密钥
    'your-app-key',             // 应用key
    'your-app-secret',          // 应用密钥
    true                        // 自动初始化token（默认为true）
);

// 如果你不想在创建实例时自动获取token，可以这样做：
// $client = new YesapiClient(
//     'https://api.example.com',
//     'your-encrypt-key',
//     'your-app-key',
//     'your-app-secret',
//     false  // 不自动初始化token
// );
// 
// // 然后在需要时手动初始化token
// try {
//     $client->initToken();
// } catch (Exception $e) {
//     echo "Token初始化失败: " . $e->getMessage() . "\n";
//     exit;
// }

// 示例1: 简单的GET请求
try {
    $result = $client
        ->path('api/user/list')
        ->params([
            'page' => 1,
            'limit' => 10
        ])
        ->timeout(5)  // 设置5秒超时
        ->retry(2)    // 设置最多重试2次
        ->get();

    echo "GET请求成功:\n";
    print_r($result);
} catch (Exception $e) {
    echo "GET请求失败: " . $e->getMessage() . "\n";
}

// 示例2: 带有请求体的POST请求
try {
    $result = $client
        ->path('api/user/create')
        ->params([
            'token' => 'session-token'  // GET参数
        ])
        ->body([
            'username' => 'testuser',   // POST请求体参数
            'email' => 'test@example.com',
            'age' => 25
        ])
        ->retry(3)  // 设置最多重试3次
        ->post();

    echo "POST请求成功:\n";
    print_r($result);
} catch (Exception $e) {
    echo "POST请求失败: " . $e->getMessage() . "\n";
}

// 示例3: 带加密的POST请求
// 注意：启用参数加密后，整个请求体会被加密为一个字符串，而不是JSON对象
try {
    $result = $client
        ->path('api/secure/data')
        ->params([
            'token' => 'secure-token'  // GET参数
        ])
        ->body([
            'sensitive_data' => 'confidential information',
            'user_id' => 12345
        ])
        ->enableParamEncrypt(true)     // 启用请求体加密 - 整个body会被加密为一个字符串
        ->enableResponseDecrypt(true)  // 启用响应解密
        ->retry(2)                     // 设置最多重试2次
        ->post();

    echo "加密POST请求成功:\n";
    print_r($result);
} catch (Exception $e) {
    echo "加密POST请求失败: " . $e->getMessage() . "\n";
}

// 示例4: 使用自动token认证的请求
// 注意：token已在客户端初始化时自动获取，并会在每个请求中自动添加到header
try {
    $result = $client
        ->path('api/protected/resource')
        ->params(['id' => 123])
        ->get();

    echo "带Token的请求成功:\n";
    print_r($result);
} catch (Exception $e) {
    echo "带Token的请求失败: " . $e->getMessage() . "\n";
}

// 示例5: 处理token过期的情况
// 注意：如果token过期，客户端会自动刷新token并重试请求
try {
    // 模拟token过期的情况
    // 在实际使用中，你不需要手动设置这些属性，客户端会自动处理
    // $client->tokenExpireAt = time() * 1000 - 1000; // 将token设为已过期
    
    $result = $client
        ->path('api/protected/data')
        ->body(['action' => 'update'])
        ->post();

    echo "Token自动刷新后的请求成功:\n";
    print_r($result);
} catch (Exception $e) {
    echo "请求失败: " . $e->getMessage() . "\n";
}
