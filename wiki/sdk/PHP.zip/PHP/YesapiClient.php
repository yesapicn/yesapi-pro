<?php

/**
 * YesapiClient - 封装对远程API的调用
 *
 * 支持链式操作，提供GET和POST请求能力，支持参数加密和结果解密
 */
class YesapiClient
{
    /**
     * @var string API域名
     */
    private $domain;

    /**
     * @var string 加密密钥
     */
    private $encryptKey;

    /**
     * @var string 应用key
     */
    private $appKey;

    /**
     * @var string 应用密钥
     */
    private $appSecret;

    /**
     * @var array GET请求参数
     */
    private $queryParams = [];

    /**
     * @var array POST请求体参数
     */
    private $bodyParams = [];

    /**
     * @var int 重试次数
     */
    private $retryTimes = 0;

    /**
     * @var bool 是否加密请求参数
     */
    private $encryptParams = false;

    /**
     * @var bool 是否解密返回结果
     */
    private $decryptResponse = false;

    /**
     * @var string 请求路径
     */
    private $path = '';

    /**
     * @var array 请求头 (键值对形式)
     */
    private $headers = [];

    /**
     * @var int 超时时间（秒）
     */
    private $timeout = 30;
    
    /**
     * @var string 访问令牌
     */
    private $accessToken = '';
    
    /**
     * @var int 令牌过期时间戳（毫秒）
     */
    private $tokenExpireAt = 0;

    /**
     * 构造函数
     *
     * @param string $domain API域名
     * @param string $encryptKey 加密密钥
     * @param string $appKey 应用key
     * @param string $appSecret 应用密钥
     * @param bool $autoInitToken 是否自动初始化token
     * @throws Exception 初始化token失败时抛出异常
     */
    public function __construct($domain, $encryptKey, $appKey, $appSecret, $autoInitToken = true)
    {
        $this->domain = rtrim($domain, '/');
        $this->encryptKey = $encryptKey;
        $this->appKey = $appKey;
        $this->appSecret = $appSecret;

        // 设置默认请求头 (键值对形式)
        $this->headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];
        
        // 自动初始化token
        if ($autoInitToken) {
            $this->initToken();
        }
    }
    
    /**
     * 初始化访问令牌
     *
     * @return bool 是否成功获取token
     * @throws Exception 获取token失败时抛出异常
     */
    public function initToken()
    {
        // 如果token未过期，直接返回true
        if ($this->accessToken && $this->tokenExpireAt > (time() * 1000)) {
            return true;
        }
        
        // 构建请求URL
        $url = $this->domain . '/api/official/auth/apply_token';
        
        // 准备请求参数
        $postData = [
            'app_key' => $this->appKey,
            'app_secret' => $this->appSecret
        ];
        
        // 初始化CURL
        $ch = curl_init();
        
        // 设置CURL选项
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        // 执行请求
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        // 处理错误
        if ($error) {
            throw new Exception("Token initialization failed: CURL Error: $error");
        }
        
        if ($httpCode !== 200) {
            throw new Exception("Token initialization failed: HTTP $httpCode");
        }
        
        // 解析响应
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Token initialization failed: Invalid JSON response");
        }
        
        // 检查响应状态
        if ($result['code'] !== 200) {
            throw new Exception("Token initialization failed: " . ($result['message'] ?? 'Unknown error'));
        }
        
        // 保存token和过期时间
        if (isset($result['data']['access_token']) && isset($result['data']['expire_at'])) {
            $this->accessToken = $result['data']['access_token'];
            $this->tokenExpireAt = $result['data']['expire_at'];
            return true;
        } else {
            throw new Exception("Token initialization failed: Missing token or expire time in response");
        }
    }

    /**
     * 设置请求路径
     *
     * @param string $path 请求路径
     * @return $this
     */
    public function path($path)
    {
        $this->path = ltrim($path, '/');
        return $this;
    }

    /**
     * 设置GET请求参数
     *
     * @param array $params 请求参数
     * @return $this
     */
    public function params(array $params)
    {
        $this->queryParams = array_merge($this->queryParams, $params);
        return $this;
    }

    /**
     * 设置POST请求体参数
     *
     * @param array $params 请求体参数
     * @return $this
     */
    public function body(array $params)
    {
        $this->bodyParams = array_merge($this->bodyParams, $params);
        return $this;
    }

    /**
     * 设置重试次数
     *
     * @param int $times 重试次数
     * @return $this
     */
    public function retry($times)
    {
        $this->retryTimes = max(0, intval($times));
        return $this;
    }

    /**
     * 设置请求头
     *
     * @param array $headers 请求头
     * @return $this
     */
    public function headers(array $headers)
    {
        $this->headers = array_merge($this->headers, $headers);
        return $this;
    }

    /**
     * 设置超时时间
     *
     * @param int $seconds 超时秒数
     * @return $this
     */
    public function timeout($seconds)
    {
        $this->timeout = $seconds;
        return $this;
    }

    /**
     * 开启参数加密
     *
     * @param bool $enable 是否启用
     * @return $this
     */
    public function enableParamEncrypt($enable = true)
    {
        $this->encryptParams = $enable;
        return $this;
    }

    /**
     * 开启结果解密
     *
     * @param bool $enable 是否启用
     * @return $this
     */
    public function enableResponseDecrypt($enable = true)
    {
        $this->decryptResponse = $enable;
        return $this;
    }

    /**
     * 执行GET请求
     *
     * @return array 响应结果
     */
    public function get()
    {
        return $this->request('GET');
    }

    /**
     * 执行POST请求
     *
     * @return array 响应结果
     */
    public function post()
    {
        return $this->request('POST');
    }

    /**
     * 执行请求
     *
     * @param string $method 请求方法
     * @return array 响应结果
     * @throws Exception 请求异常
     */
    private function request($method)
    {
        $attempts = $this->retryTimes + 1;
        $lastException = null;

        for ($attempt = 1; $attempt <= $attempts; $attempt++) {
            try {
                return $this->executeRequest($method);
            } catch (Exception $e) {
                $lastException = $e;
                
                // 如果是最后一次尝试，抛出异常
                if ($attempt === $attempts) {
                    throw new Exception(
                        "Request failed after {$this->retryTimes} retries: " . $e->getMessage(),
                        $e->getCode(),
                        $e
                    );
                }
                
                // 等待一段时间后重试（使用指数退避策略）
                $waitTime = min(pow(2, $attempt - 1) * 1000, 5000); // 最多等待5秒
                usleep($waitTime * 1000); // 转换为微秒
            }
        }
    }

    /**
     * 执行单次请求
     *
     * @param string $method 请求方法
     * @return array 响应结果
     * @throws Exception 请求异常
     */
    private function executeRequest($method)
    {
        // 检查token是否过期，如果过期则刷新
        if ($this->tokenExpireAt > 0 && $this->tokenExpireAt <= (time() * 1000)) {
            $this->initToken();
        }

        // 构建URL和查询参数
        $url = $this->domain . '/' . $this->path;
        if (!empty($this->queryParams)) {
            $url .= '?' . http_build_query($this->queryParams);
        }

        // 准备请求头 - 将键值对转换为CURL需要的格式
        $headers = [];
        foreach ($this->headers as $name => $value) {
            $headers[] = "$name: $value";
        }
        if ($this->accessToken) {
            $headers[] = 'Access-Token: ' . $this->accessToken;
        }

        // 初始化CURL
        $ch = curl_init();

        if ($method === 'GET') {
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        } else {
            // 处理POST请求体
            $postData = $this->bodyParams;
            
            // 如果启用了参数加密，加密整个body
            if ($this->encryptParams && !empty($postData)) {
                $postData = $this->encrypt(json_encode($postData));
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            } else {
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
            }
        }

        // 设置CURL选项
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);  // 使用更新后的请求头
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        // 执行请求
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        // 处理错误
        if ($error) {
            throw new Exception("CURL Error: $error");
        }

        if ($httpCode >= 500) {
            throw new Exception("Server Error: HTTP $httpCode");
        }

        if ($httpCode === 401) {
            // Token可能已失效，尝试刷新token并重试请求
            $this->initToken();
            return $this->executeRequest($method);
        }

        // 解析响应
        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response: $response");
        }

        // 如果启用了结果解密，解密data字段
        if ($this->decryptResponse && isset($result['data']) && is_string($result['data'])) {
            $decrypted = $this->decrypt($result['data']);
            $decryptedJson = json_decode($decrypted,true);
            $result['data'] = !empty($decryptedJson)?$decryptedJson:$decrypted;
        }

        // 重置参数，以便下次请求
        $this->resetParams();

        return $result;
    }

    /**
     * 重置请求参数
     */
    private function resetParams()
    {
        $this->queryParams = [];
        $this->bodyParams = [];
        $this->path = '';
    }

    /**
     * AES-128-CBC加密
     *
     * @param string $data 待加密数据
     * @return string 加密后的Base64字符串
     */
    private function encrypt($data)
    {
        // 使用加密密钥作为IV
        $iv = $this->encryptKey;
        
        // 如果密钥长度超过16字节，截取前16字节
        if (strlen($iv) > 16) {
            $iv = substr($iv, 0, 16);
        }
        // 如果密钥长度不足16字节，用0填充
        elseif (strlen($iv) < 16) {
            $iv = str_pad($iv, 16, '0');
        }
        
        // PKCS7填充
        $padding = 16 - (strlen($data) % 16);
        $data .= str_repeat(chr($padding), $padding);

        $encrypted = openssl_encrypt(
            $data,
            'AES-128-CBC',
            $this->encryptKey,
            OPENSSL_RAW_DATA,
            $iv
        );

        return base64_encode($encrypted);
    }

    /**
     * AES-128-CBC解密
     *
     * @param string $data Base64编码的加密数据
     * @return string 解密后的数据
     */
    private function decrypt($data)
    {
        // 使用加密密钥作为IV
        $iv = $this->encryptKey;
        
        // 如果密钥长度超过16字节，截取前16字节
        if (strlen($iv) > 16) {
            $iv = substr($iv, 0, 16);
        }
        // 如果密钥长度不足16字节，用0填充
        elseif (strlen($iv) < 16) {
            $iv = str_pad($iv, 16, '0');
        }
        
        //$data = base64_decode($data);
        $data = hex2bin($data);
        $decrypted = openssl_decrypt(
            $data,
            'AES-128-CBC',
            $this->encryptKey,
            OPENSSL_RAW_DATA,
            $iv
        );

        if ($decrypted === false) {
            throw new Exception("Decryption failed: " . openssl_error_string());
        }

        // 移除PKCS7填充
        $padding = ord($decrypted[strlen($decrypted) - 1]);
        if ($padding > 0 && $padding <= 16) {
            return substr($decrypted, 0, -$padding);
        }

        return $decrypted;
    }

    /**
     * 获取完整URL
     *
     * @return string 完整URL
     */
    public function getFullUrl()
    {
        return $this->domain . '/' . $this->path;
    }
}
