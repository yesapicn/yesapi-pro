<?php

require_once 'YesapiClient.php';

/**
 * YesapiClient 使用示例
 */

// 初始化客户端
$domain = 'https://api.example.com';  // 替换为实际的API域名
$encryptKey = 'your-encrypt-key';     // 替换为实际的加密密钥
$appKey = 'your-app-key';             // 替换为实际的应用key
$appSecret = 'your-app-secret';       // 替换为实际的应用密钥

$client = new YesapiClient($domain, $encryptKey, $appKey, $appSecret);

// 示例1: 简单的GET请求
try {
    $response = $client->path('api/v1/info')
                      ->param('name', 'test')
                      ->get();

    echo "示例1 - GET请求结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例1 - 错误: " . $e->getMessage() . "\n\n";
}

// 示例2: 带参数的POST请求
try {
    $response = $client->path('api/v1/data')
                      ->params([
                          'name' => 'test',
                          'age' => 25,
                          'interests' => ['coding', 'reading']
                      ])
                      ->post();

    echo "示例2 - POST请求结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例2 - 错误: " . $e->getMessage() . "\n\n";
}

// 示例3: 启用参数加密的POST请求
try {
    $response = $client->path('api/v1/secure-data')
                      ->params([
                          'username' => 'secure_user',
                          'password' => 'secure_password',
                          'data' => 'sensitive information'
                      ])
                      ->enableParamEncrypt(true)  // 启用参数加密
                      ->post();

    echo "示例3 - 加密参数POST请求结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例3 - 错误: " . $e->getMessage() . "\n\n";
}

// 示例4: 启用结果解密的POST请求
try {
    $response = $client->path('api/v1/get-encrypted-data')
                      ->params(['id' => 123])
                      ->enableResponseDecrypt(true)  // 启用结果解密
                      ->post();

    echo "示例4 - 结果解密POST请求结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例4 - 错误: " . $e->getMessage() . "\n\n";
}

// 示例5: 同时启用参数加密和结果解密
try {
    $response = $client->path('api/v1/fully-secure')
                      ->params([
                          'secure_data' => 'top secret',
                          'timestamp' => time()
                      ])
                      ->enableParamEncrypt(true)     // 启用参数加密
                      ->enableResponseDecrypt(true)  // 启用结果解密
                      ->timeout(60)                  // 设置超时时间
                      ->post();

    echo "示例5 - 完全加密通信结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例5 - 错误: " . $e->getMessage() . "\n\n";
}

// 示例6: 自定义请求头
try {
    $response = $client->path('api/v1/custom-headers')
                      ->param('test', 'value')
                      ->headers([
                          'X-Custom-Header: CustomValue',
                          'Authorization: Bearer token123'
                      ])
                      ->get();

    echo "示例6 - 自定义请求头结果:\n";
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    echo "\n\n";
} catch (Exception $e) {
    echo "示例6 - 错误: " . $e->getMessage() . "\n\n";
}
