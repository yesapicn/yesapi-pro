// 导入YesAPISDK模块
const { callApi, exampleGetRequest, examplePostRequest } = require('./YesapiClient');

/**
 * 使用SDK的示例函数
 */
async function useSdkExamples() {
    // 使用SDK中的GET请求示例
    await exampleGetRequest({ choice1: "剪刀" }, true);

    // 使用SDK中的POST请求示例
    await examplePostRequest({ guess2: "2", guess3: "3" }, true);
}

async function main() {
    try {
        await useSdkExamples();

    } catch (error) {
        console.error("演示过程中出错:", error);
    }
}

// 执行主函数
main().catch(error => {
    console.error("程序执行失败:", error);
});