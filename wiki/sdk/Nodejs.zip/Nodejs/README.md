# YesAPI Node.js SDK

这是 YesAPI 的 Node.js 版本 SDK，提供了与服务端 API 交互的简单方式。

## 功能特点
- 支持链式调用（Fluent Interface）
- 提供 GET 和 POST 请求能力
- 支持响应数据 AES 解密
- 支持请求头设置
- 支持超时时间设置
- 支持请求失败自动重试
- 支持自定义重试次数和等待时间
- 支持访问令牌自动申请

## 环境要求
- Node.js v14.x 或更高版本

- 依赖库：
    - axios
    - axios-retry
    - crypto

## 安装
1. 克隆代码到本地
2. 进入项目目录
3. 安装依赖：
```bash
npm install
```

## 使用示例

### 初始化 SDK 并调用接口

```javascript
const { exampleGetRequest, examplePostRequest } = require('./YesAPISDK');

// 调用 GET 接口并启用解密
exampleGetRequest({ choice1: "剪刀" }, true);

// 调用 POST 接口，不启用解密
examplePostRequest({ guess2: "2", guess3: "3" }, false);
```

### 自定义调用接口

```javascript
const { callApi } = require('./YesAPISDK');

callApi('/online-api/v1/get_sdk/test', {
    method: 'GET',
    params: { choice1: "石头" },
    decrypt: true,
    timeout: 10000,
    retryTimes: 3,
    retryWait: 1000
}).then(result => {
    console.log("接口响应：", result);
});
```

## 主要类和方法说明

### YesAPISDK
SDK 核心类，用于配置 API 地址、AES 密钥、Token 获取等。

### 构造函数
```javascript
new YesAPISDK(apiUrl, aesKey = null)
```

### 方法
| 方法                                  | 描述 |
|-------------------------------------|------|
| AuthApplyToken(appKey, appSecret) |获取访问令牌|
| header(headers)                     |设置请求头|
| enableDecrypt(enable = true)              |启用或禁用响应数据 AES 解密|
|setRetry(times = 3, wait = 1000)|设置请求失败自动重试次数和等待时间|

### YesAPISDKRequest
| 方法                                  | 描述 |
|-------------------------------------|------|
|get(path, params = null, timeout = 10000)|发起 GET 请求|
|post(path, data = {}, timeout = 10000)|发起 POST 请求|

### callApi()
| 参数 | 类型 | 默认值 | 描述 | 
|------|------|--------|------|
| route | str | 必填 | 接口路径 |
| method | str | "GET" | 请求方法（GET/POST） |
| params | object | null | GET 请求参数 |
| data | object | null | POST 请求体 |
| decrypt | boolean | false | 是否启用响应解密 |
| timeout | number | 10000 | 请求超时时间（毫秒） |
| retryTimes | number | 3 | 请求失败自动重试次数 |
| retryWait | number | 1000 | 请求失败自动重试等待时间（毫秒） |
w
## 模块导出
```javascript
const { callApi, exampleGetRequest, examplePostRequest } = require('./YesAPISDK');
```

## 注意事项
1. 修改 APP_KEY, APP_SECRET, AES_KEY 为你自己的应用密钥。
2. 建议在生产环境中合理设置 timeout 和增加重试机制。
3. 所有接口调用前都会自动获取 Token，无需手动刷新。
4. 示例函数仅用于测试，实际使用请根据业务需求封装。