const axios = require('axios');
const crypto = require('crypto');
const axiosRetry = require('axios-retry').default;

// 配置信息放在最上面，便于快速修改
const API_URL = "https://api.example.com";
const APP_KEY = "your-app-key";
const APP_SECRET = "your-secret-key";
const AES_KEY = "your-aes-key";

class YesapiClient {
    constructor(apiUrl, aesKey = null) {
        this.apiUrl = apiUrl;
        this._headers = {};
        this.aesKey = aesKey; // AES 密钥
        this.enable_response_decrypt = false; // 是否启用响应解密
        this.retry_times = 3; // 默认最大重试次数
        this.retry_wait = 1000; // 默认每次等待时间（毫秒）
    }

    enableDecrypt(enable = true) {
        this.enable_response_decrypt = enable;
        return this;
    }

    setRetry(times = 3, wait = 1000) {
        this.retry_times = times;
        this.retry_wait = wait;
        return this;
    }

    _aesDecrypt(encryptedData) {
        if (!this.aesKey) {
            throw new Error("AES key 未设置，无法解密。");
        }

        const key = Buffer.from(this.aesKey, 'utf-8');
        const encryptedBuffer = Buffer.from(encryptedData, 'hex');

        const cipher = crypto.createDecipheriv('aes-128-cbc', key, key);
        let decrypted = cipher.update(encryptedBuffer);
        decrypted = Buffer.concat([decrypted, cipher.final()]);

        return decrypted.toString('utf8');
    }

    async AuthApplyToken(appKey, appSecret) {
        const applyTokenUrl = this.apiUrl + "/api/official/auth/apply_token";
        const data = {
            app_key: appKey,
            app_secret: appSecret
        };

        try {
            const response = await axios.post(applyTokenUrl, data);
            return response.data?.data?.access_token || '';
        } catch (error) {
            console.error("获取 Token 失败:", error.message);
            return '';
        }
    }

    header(headers) {
        this._headers = headers;
        return new Request(this);
    }
}

axiosRetry(axios, {
    retries: 3, // 默认重试次数
    retryDelay: (retryCount) => {
        return retryCount * 1000; // 每次重试延迟 1s、2s、3s...
    },
    retryCondition: (error) => {
        // 只对网络错误和5xx状态码进行重试
        return axiosRetry.isNetworkOrIdempotentRequestError(error) || error.response?.status >= 500;
    }
});

class Request {
    constructor(client) {
        this.client = client;
    }

    async get(path, params, timeout = 10000) {
        const url = this.client.apiUrl + path;

        try {
            const response = await axios.get(url, {
                headers: this.client._headers,
                params,
                timeout,
                retries: this.client.retry_times,
                retryDelay: (count) => count * this.client.retry_wait
            });

            let result = response.data;

            if (this.client.enable_response_decrypt && result.data) {
                try {
                    if (/^[0-9a-fA-F]+$/.test(result.data)) {
                        result.data = this.client._aesDecrypt(result.data);
                    }
                } catch (e) {
                    console.error("GET 解密失败:", e.message);
                }
            }

            return result;

        } catch (error) {
            console.error("GET 请求失败:", error.message);
            throw error;
        }
    }

    async post(path, data, timeout = 10000) {
        const url = this.client.apiUrl + path;

        try {
            const response = await axios.post(url, data, {
                headers: this.client._headers,
                timeout,
                retries: this.client.retry_times,
                retryDelay: (count) => count * this.client.retry_wait
            });

            let result = response.data;

            if (this.client.enable_response_decrypt && result.data) {
                try {
                    if (/^[0-9a-fA-F]+$/.test(result.data)) {
                        result.data = this.client._aesDecrypt(result.data);
                    }
                } catch (e) {
                    console.error("POST 解密失败:", e.message);
                }
            }

            return result;

        } catch (error) {
            console.error("POST 请求失败:", error.message);
            throw error;
        }
    }
}

// 通用调用函数
async function callApi(route, { method = 'GET', params, data, decrypt = false, timeout = 10000, retryTimes = 3, retryWait = 1000 } = {}) {
    const client = new YesapiClient(API_URL, AES_KEY);
    client.setRetry(retryTimes, retryWait);

    if (decrypt && AES_KEY) {
        client.enableDecrypt(true);
    }

    const token = await client.AuthApplyToken(APP_KEY, APP_SECRET);
    const request = client.header({
        'access-token': token
    });

    if (method.toUpperCase() === 'GET') {
        return await request.get(route, params, timeout);
    } else if (method.toUpperCase() === 'POST') {
        return await request.post(route, data || {}, timeout);
    } else {
        throw new Error(`不支持的 HTTP 方法: ${method}`);
    }
}

// 示例：GET 请求（可选传参）
async function exampleGetRequest({ choice1 } = {}, decrypt = false) {
    try {
        const result = await callApi('/online-api/v1/get_sdk/test', {
            method: 'GET',
            params: { choice1 },
            decrypt,
            timeout: 10000,
            retryTimes: 3,
            retryWait: 1000
        });
        console.log(result);
        return result;
    } catch (err) {
        console.error(err.message);
    }
}

// 示例：POST 请求（可选传参）
async function examplePostRequest({ guess1, guess2, guess3 } = {}, decrypt = false) {
    try {
        const result = await callApi('/online-api/v1/post_sdk/test', {
            method: 'POST',
            data: { guess1, guess2, guess3 },
            decrypt,
            timeout: 10000,
            retryTimes: 3,
            retryWait: 1000
        });
        console.log(result);
        return result;
    } catch (err) {
        console.error(err.message);
    }
}

// 主入口（可选）
if (require.main === module) {
    (async () => {
        try {
            await exampleGetRequest({ choice1: "剪刀" }, true);
            await examplePostRequest({ guess1: "1", guess2: "2", guess3: "3" }, true);
        } catch (error) {
            console.error("执行过程中出错:", error);
        }
    })().catch(err => {
        console.error("主程序执行失败:", err);
    });
}

// 导出模块供其他文件使用
module.exports = {
    callApi,
    exampleGetRequest,
    examplePostRequest
};
