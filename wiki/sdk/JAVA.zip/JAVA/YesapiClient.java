
import cn.hutool.crypto.Mode;
import cn.hutool.crypto.Padding;
import cn.hutool.crypto.symmetric.AES;
import cn.hutool.json.JSONException;
import cn.hutool.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * YesapiClient - 封装对远程API的调用
 *
 * 支持链式操作，提供GET和POST请求能力，支持参数加密和结果解密
 */
public class YesapiClient {
    /**
     * API域名
     */
    private String domain;

    /**
     * 加密密钥
     */
    private String encryptKey;

    /**
     * 应用key
     */
    private String appKey;

    /**
     * 应用密钥
     */
    private String appSecret;

    /**
     * GET请求参数
     */
    private Map<String, String> queryParams = new HashMap<>();

    /**
     * POST请求体参数
     */
    private Map<String, Object> bodyParams = new HashMap<>();

    /**
     * 重试次数
     */
    private int retryTimes = 0;

    /**
     * 是否加密请求参数
     */
    private boolean encryptParams = false;

    /**
     * 是否解密返回结果
     */
    private boolean decryptResponse = false;

    /**
     * 请求路径
     */
    private String path = "";

    /**
     * 请求头 (键值对形式)
     */
    private Map<String, String> headers = new HashMap<>();

    /**
     * 超时时间（秒）
     */
    private int timeout = 30;

    /**
     * 访问令牌
     */
    private String accessToken = "";

    /**
     * 令牌过期时间戳（毫秒）
     */
    private long tokenExpireAt = 0;

    /**
     * 构造函数
     *
     * @param domain API域名
     * @param encryptKey 加密密钥
     * @param appKey 应用key
     * @param appSecret 应用密钥
     * @param autoInitToken 是否自动初始化token
     * @throws Exception 初始化token失败时抛出异常
     */
    public YesapiClient(String domain, String encryptKey, String appKey, String appSecret, boolean autoInitToken) throws Exception {
        this.domain = domain.endsWith("/") ? domain.substring(0, domain.length() - 1) : domain;
        this.encryptKey = encryptKey;
        this.appKey = appKey;
        this.appSecret = appSecret;

        // 设置默认请求头 (键值对形式)
        this.headers.put("Content-Type", "application/json");
        this.headers.put("Accept", "application/json");

        // 自动初始化token
        if (autoInitToken) {
            this.initToken();
        }
    }

    /**
     * 构造函数 - 不自动初始化token
     *
     * @param domain API域名
     * @param encryptKey 加密密钥
     * @param appKey 应用key
     * @param appSecret 应用密钥
     * @throws Exception 初始化失败时抛出异常
     */
    public YesapiClient(String domain, String encryptKey, String appKey, String appSecret) throws Exception {
        this(domain, encryptKey, appKey, appSecret, false);
    }

    /**
     * 初始化访问令牌
     *
     * @return boolean 是否成功获取token
     * @throws Exception 获取token失败时抛出异常
     */
    public boolean initToken() throws Exception {
        // 如果token未过期，直接返回true
        if (!this.accessToken.isEmpty() && this.tokenExpireAt > System.currentTimeMillis()) {
            return true;
        }

        // 构建请求URL
        String url = this.domain + "/api/official/auth/apply_token";

        // 准备请求参数
        JSONObject postData = new JSONObject();
        postData.set("app_key", this.appKey);
        postData.set("app_secret", this.appSecret);

        // 初始化HTTP连接
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();

        // 设置请求方法和头信息
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Accept", "application/json");
        connection.setConnectTimeout(this.timeout * 1000);
        connection.setReadTimeout(this.timeout * 1000);
        connection.setDoOutput(true);

        // 发送请求数据
        try (DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream())) {
            outputStream.write(postData.toString().getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
        }

        // 获取响应状态码
        int httpCode = connection.getResponseCode();

        // 处理错误
        if (httpCode != 200) {
            throw new Exception("Token initialization failed: HTTP " + httpCode);
        }

        // 读取响应
        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        }

        // 解析响应
        JSONObject result;
        try {
            result = new JSONObject(response.toString());
        } catch (JSONException e) {
            throw new Exception("Token initialization failed: Invalid JSON response");
        }

        // 检查响应状态
        if (result.getInt("code") != 200) {
            throw new Exception("Token initialization failed: " + result.getStr("message", "Unknown error"));
        }

        // 保存token和过期时间
        JSONObject data = result.getJSONObject("data");
        if (data.containsKey("access_token") && data.containsKey("expire_at")) {
            this.accessToken = data.getStr("access_token");
            this.tokenExpireAt = data.getLong("expire_at");
            return true;
        } else {
            throw new Exception("Token initialization failed: Missing token or expire time in response");
        }
    }

    /**
     * 设置请求路径
     *
     * @param path 请求路径
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient path(String path) {
        this.path = path.startsWith("/") ? path.substring(1) : path;
        return this;
    }

    /**
     * 设置GET请求参数
     *
     * @param params 请求参数
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient params(Map<String, String> params) {
        this.queryParams.putAll(params);
        return this;
    }

    /**
     * 设置POST请求体参数
     *
     * @param params 请求体参数
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient body(Map<String, Object> params) {
        this.bodyParams.putAll(params);
        return this;
    }

    /**
     * 设置重试次数
     *
     * @param times 重试次数
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient retry(int times) {
        this.retryTimes = Math.max(0, times);
        return this;
    }

    /**
     * 设置请求头
     *
     * @param headers 请求头键值对数组，如 {"Content-Type": "application/json"}
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient headers(Map<String, String> headers) {
        this.headers.putAll(headers);
        return this;
    }

    /**
     * 设置超时时间
     *
     * @param seconds 超时秒数
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient timeout(int seconds) {
        this.timeout = seconds;
        return this;
    }

    /**
     * 开启参数加密
     *
     * @param enable 是否启用
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient enableParamEncrypt(boolean enable) {
        this.encryptParams = enable;
        return this;
    }

    /**
     * 开启结果解密
     *
     * @param enable 是否启用
     * @return this 当前实例，支持链式调用
     */
    public YesapiClient enableResponseDecrypt(boolean enable) {
        this.decryptResponse = enable;
        return this;
    }

    /**
     * 执行GET请求
     *
     * @return JSONObject 响应结果
     * @throws Exception 请求异常
     */
    public JSONObject get() throws Exception {
        return this.request("GET");
    }

    /**
     * 执行POST请求
     *
     * @return JSONObject 响应结果
     * @throws Exception 请求异常
     */
    public JSONObject post() throws Exception {
        return this.request("POST");
    }

    /**
     * 执行请求
     *
     * @param method 请求方法
     * @return JSONObject 响应结果
     * @throws Exception 请求异常
     */
    private JSONObject request(String method) throws Exception {
        int attempts = this.retryTimes + 1;
        Exception lastException = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return this.executeRequest(method);
            } catch (Exception e) {
                lastException = e;

                // 如果是最后一次尝试，抛出异常
                if (attempt == attempts) {
                    throw new Exception(
                            "Request failed after " + this.retryTimes + " retries: " + e.getMessage(),
                            e
                    );
                }

                // 等待一段时间后重试（使用指数退避策略）
                long waitTime = Math.min((long) Math.pow(2, attempt - 1) * 1000, 5000); // 最多等待5秒
                TimeUnit.MILLISECONDS.sleep(waitTime);
            }
        }

        // 这行代码永远不会执行，但Java编译器需要它
        throw lastException;
    }

    /**
     * 执行单次请求
     *
     * @param method 请求方法
     * @return JSONObject 响应结果
     * @throws Exception 请求异常
     */
    private JSONObject executeRequest(String method) throws Exception {
        // 检查token是否过期，如果过期则刷新
        if (this.tokenExpireAt > 0 && this.tokenExpireAt <= System.currentTimeMillis()) {
            this.initToken();
        }

        // 构建URL和查询参数
        StringBuilder urlBuilder = new StringBuilder(this.domain + "/" + this.path);
        if (!this.queryParams.isEmpty()) {
            urlBuilder.append("?");
            boolean first = true;
            for (Map.Entry<String, String> entry : this.queryParams.entrySet()) {
                if (!first) {
                    urlBuilder.append("&");
                }
                urlBuilder.append(entry.getKey()).append("=").append(entry.getValue());
                first = false;
            }
        }

        String urlString = urlBuilder.toString();
        URL url = new URL(urlString);

        // 初始化HTTP连接
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        // 设置请求方法
        connection.setRequestMethod(method);

        // 设置请求头
        for (Map.Entry<String, String> entry : this.headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }

        // 如果有访问令牌，添加到请求头
        if (!this.accessToken.isEmpty()) {
            connection.setRequestProperty("Access-Token", this.accessToken);
        }

        // 设置超时
        connection.setConnectTimeout(this.timeout * 1000);
        connection.setReadTimeout(this.timeout * 1000);

        if (method.equals("POST")) {
            connection.setDoOutput(true);

            // 处理POST请求体
            if (!this.bodyParams.isEmpty()) {
                JSONObject postData = new JSONObject(this.bodyParams);
                String postDataString;

                // 如果启用了参数加密，加密整个body
                if (this.encryptParams) {
                    postDataString = this.encrypt(postData.toString());
                } else {
                    postDataString = postData.toString();
                }

                // 发送请求数据
                try (DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream())) {
                    outputStream.write(postDataString.getBytes(StandardCharsets.UTF_8));
                    outputStream.flush();
                }
            }
        }

        // 获取响应状态码
        int httpCode = connection.getResponseCode();

        // 处理错误
        if (httpCode >= 500) {
            throw new Exception("Server Error: HTTP " + httpCode);
        }

        if (httpCode == 401) {
            // Token可能已失效，尝试刷新token并重试请求
            this.initToken();
            return this.executeRequest(method);
        }

        // 读取响应
        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                httpCode >= 400 ? connection.getErrorStream() : connection.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
        }

        String responseString = response.toString();
        // 如果启用了结果解密，解密响应
        if (this.decryptResponse) {
            responseString = this.decrypt(responseString);
        }
        // 解析JSON响应
        try {
            return new JSONObject(responseString);
        } catch (JSONException e) {
            throw new Exception("Invalid JSON response: " + responseString);
        }
    }

    /**
     * 加密数据
     *
     * @param data 待加密数据
     * @return String 加密后的Base64字符串
     * @throws Exception 加密异常
     */
    private String encrypt(String data) throws Exception {
        try {
            // 使用AES/CBC/PKCS5Padding模式
            AES aes = new AES(Mode.CBC, Padding.PKCS5Padding, this.encryptKey.getBytes(),this.encryptKey.getBytes());
            String encrypt = aes.encryptHex(data);

            // 返回Base64编码的加密数据
            return encrypt;
        } catch (Exception e) {
            throw new Exception("Encryption failed: " + e.getMessage(), e);
        }
    }

    /**
     * 解密数据
     *
     * @param data 待解密的Base64字符串
     * @return String 解密后的数据
     * @throws Exception 解密异常
     */
    private String decrypt(String data) throws Exception {
        try {
            JSONObject dataJson = new JSONObject(data);
            // 使用AES/CBC/PKCS5Padding模式
            AES aes = new AES(Mode.CBC, Padding.PKCS5Padding, this.encryptKey.getBytes(),this.encryptKey.getBytes());
            String decrypt = aes.decryptStr(dataJson.getStr("data"));
            JSONObject decryptJson = new JSONObject(decrypt);
            if(decryptJson!=null) {
                dataJson.set("data", decryptJson);
            }else{
                dataJson.set("data", decrypt);
            }
            // 返回解密后的字符串
            return dataJson.toString();
        } catch (Exception e) {
            throw new Exception("Decryption failed: " + e.getMessage(), e);
        }
    }
}