import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class Example {
    public static void main(String[] args) {
        try {
            // 创建YesapiClient实例（自动初始化token）
            YesapiClient client = new YesapiClient(
                "https://your-api-domain.com",  // API域名
                "your-encrypt-key",             // 加密密钥
                "your-app-key",                 // 应用key
                "your-app-secret",              // 应用密钥
                true                            // 自动初始化token
            );

            // 示例1：简单的GET请求
            JSONObject response1 = client
                .path("api/user/info")          // 设置请求路径
                .params(new HashMap<String, String>() {{  // 设置GET参数
                    put("user_id", "123");
                }})
                .get();                         // 执行GET请求
            System.out.println("GET Response: " + response1.toString(2));

            // 示例2：带加密的POST请求
            Map<String, Object> postData = new HashMap<>();
            postData.put("name", "John Doe");
            postData.put("email", "john@example.com");

            JSONObject response2 = client
                .path("api/user/create")        // 设置请求路径
                .body(postData)                 // 设置POST数据
                .enableParamEncrypt(true)       // 启用参数加密
                .enableResponseDecrypt(true)    // 启用响应解密
                .retry(3)                       // 设置重试次数
                .timeout(60)                    // 设置超时时间（秒）
                .headers(new HashMap<String, String>() {{  // 设置自定义请求头
                    put("X-Custom-Header", "value");
                }})
                .post();                        // 执行POST请求
            System.out.println("POST Response: " + response2.toString(2));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
