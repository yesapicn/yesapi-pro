# YesAPI Java SDK

这是 YesAPI 的 Java 版本 SDK，提供了与服务端 API 交互的简单方式。

## 功能特点

- 支持链式操作
- 提供 GET 和 POST 请求能力
- 支持参数加密和结果解密
- 支持请求头设置
- 支持超时设置
- 支持重试机制
- 支持访问令牌自动初始化和刷新

## 环境要求

- Java 8 或更高版本
- Maven 3.x

## 安装

1. 克隆代码到本地
2. 进入项目目录
3. 执行 Maven 安装：

```bash
cd yesapi-java-sdk/JAVA
mvn clean install
```

## 使用示例

```java
// 创建 YesapiClient 实例（自动初始化 token）
YesapiClient client = new YesapiClient(
    "https://your-api-domain.com",  // API域名
    "your-encrypt-key",             // 加密密钥
    "your-app-key",                 // 应用key
    "your-app-secret",              // 应用密钥
    true                            // 自动初始化token
);

// 执行 GET 请求
JSONObject response = client
    .path("api/user/info")          // 设置请求路径
    .params(new HashMap<String, String>() {{  // 设置GET参数
        put("user_id", "123");
    }})
    .get();                         // 执行GET请求

// 执行带加密的 POST 请求
Map<String, Object> postData = new HashMap<>();
postData.put("name", "John Doe");
postData.put("email", "john@example.com");

JSONObject response = client
    .path("api/user/create")        // 设置请求路径
    .body(postData)                 // 设置POST数据
    .enableParamEncrypt(true)       // 启用参数加密
    .enableResponseDecrypt(true)    // 启用响应解密
    .retry(3)                       // 设置重试次数
    .timeout(60)                    // 设置超时时间（秒）
    .headers(new HashMap<String, String>() {{  // 设置自定义请求头
        put("X-Custom-Header", "value");
    }})
    .post();                        // 执行POST请求
```

## 主要方法

- `path(String path)` - 设置请求路径
- `params(Map<String, String> params)` - 设置 GET 请求参数
- `body(Map<String, Object> params)` - 设置 POST 请求体参数
- `retry(int times)` - 设置重试次数
- `headers(Map<String, String> headers)` - 设置请求头
- `timeout(int seconds)` - 设置超时时间
- `enableParamEncrypt(boolean enable)` - 开启/关闭参数加密
- `enableResponseDecrypt(boolean enable)` - 开启/关闭结果解密
- `get()` - 执行 GET 请求
- `post()` - 执行 POST 请求

## 错误处理

SDK 使用异常机制处理错误。所有的错误都会抛出 Exception，包含详细的错误信息。建议使用 try-catch 块来处理可能的异常：

```java
try {
    JSONObject response = client.path("api/user/info").get();
    // 处理响应...
} catch (Exception e) {
    // 处理错误...
    e.printStackTrace();
}
```

## 注意事项

1. 确保在使用前正确设置 API 域名、加密密钥、应用 key 和应用密钥
2. 如果需要使用加密功能，请确保加密密钥正确
3. 建议在生产环境中适当设置重试次数和超时时间
4. 访问令牌会自动管理，包括初始化和刷新，无需手动处理
