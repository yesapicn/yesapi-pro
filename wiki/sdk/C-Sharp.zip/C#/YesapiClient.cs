using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace YesAPI
{
    /// <summary>
    /// YesapiClient - 封装对远程API的调用
    ///
    /// 支持链式操作，提供GET和POST请求能力，支持参数加密和结果解密
    /// </summary>
    public class YesapiClient
    {
        /// <summary>
        /// API域名
        /// </summary>
        private readonly string _domain;

        /// <summary>
        /// 加密密钥
        /// </summary>
        private readonly string _encryptKey;

        /// <summary>
        /// 应用key
        /// </summary>
        private readonly string _appKey;

        /// <summary>
        /// 应用密钥
        /// </summary>
        private readonly string _appSecret;

        /// <summary>
        /// GET请求参数
        /// </summary>
        private Dictionary<string, string> _queryParams = new Dictionary<string, string>();

        /// <summary>
        /// POST请求体参数
        /// </summary>
        private Dictionary<string, object> _bodyParams = new Dictionary<string, object>();

        /// <summary>
        /// 重试次数
        /// </summary>
        private int _retryTimes = 0;

        /// <summary>
        /// 是否加密请求参数
        /// </summary>
        private bool _encryptParams = false;

        /// <summary>
        /// 是否解密返回结果
        /// </summary>
        private bool _decryptResponse = false;

        /// <summary>
        /// 请求路径
        /// </summary>
        private string _path = "";

        /// <summary>
        /// 请求头 (键值对形式)
        /// </summary>
        private Dictionary<string, string> _headers = new Dictionary<string, string>();

        /// <summary>
        /// 超时时间（秒）
        /// </summary>
        private int _timeout = 30;

        /// <summary>
        /// 访问令牌
        /// </summary>
        private string _accessToken = "";

        /// <summary>
        /// 令牌过期时间戳（毫秒）
        /// </summary>
        private long _tokenExpireAt = 0;

        /// <summary>
        /// HTTP客户端
        /// </summary>
        private readonly HttpClient _httpClient;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="domain">API域名</param>
        /// <param name="encryptKey">加密密钥</param>
        /// <param name="appKey">应用key</param>
        /// <param name="appSecret">应用密钥</param>
        /// <param name="autoInitToken">是否自动初始化token</param>
        public YesapiClient(string domain, string encryptKey, string appKey, string appSecret, bool autoInitToken = true)
        {
            _domain = domain.TrimEnd('/');
            _encryptKey = encryptKey;
            _appKey = appKey;
            _appSecret = appSecret;

            // 设置默认请求头 (键值对形式)
            _headers = new Dictionary<string, string>
            {
                { "Content-Type", "application/json" },
                { "Accept", "application/json" }
            };

            // 创建HTTP客户端
            _httpClient = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(_timeout)
            };

            // 自动初始化token
            if (autoInitToken)
            {
                InitTokenAsync().GetAwaiter().GetResult();
            }
        }

        /// <summary>
        /// 初始化访问令牌
        /// </summary>
        /// <returns>是否成功获取token</returns>
        public async Task<bool> InitTokenAsync()
        {
            // 如果token未过期，直接返回true
            if (!string.IsNullOrEmpty(_accessToken) && _tokenExpireAt > DateTimeOffset.UtcNow.ToUnixTimeMilliseconds())
            {
                return true;
            }

            // 构建请求URL
            string url = $"{_domain}/api/official/auth/apply_token";

            // 准备请求参数
            var postData = new Dictionary<string, string>
            {
                { "app_key", _appKey },
                { "app_secret", _appSecret }
            };

            // 创建请求内容
            var content = new StringContent(
                JsonSerializer.Serialize(postData),
                Encoding.UTF8,
                "application/json"
            );

            // 设置请求头
            var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                // 发送请求
                var response = await _httpClient.SendAsync(request);

                // 检查HTTP状态码
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Token initialization failed: HTTP {(int)response.StatusCode}");
                }

                // 读取响应内容
                string responseContent = await response.Content.ReadAsStringAsync();

                // 解析JSON响应
                using (JsonDocument document = JsonDocument.Parse(responseContent))
                {
                    JsonElement root = document.RootElement;

                    // 检查响应状态
                    if (root.TryGetProperty("code", out JsonElement codeElement) && codeElement.GetInt32() != 200)
                    {
                        string message = "Unknown error";
                        if (root.TryGetProperty("message", out JsonElement messageElement))
                        {
                            message = messageElement.GetString();
                        }
                        throw new Exception($"Token initialization failed: {message}");
                    }

                    // 保存token和过期时间
                    if (root.TryGetProperty("data", out JsonElement dataElement))
                    {
                        if (dataElement.TryGetProperty("access_token", out JsonElement tokenElement) &&
                            dataElement.TryGetProperty("expire_at", out JsonElement expireElement))
                        {
                            _accessToken = tokenElement.GetString();
                            _tokenExpireAt = expireElement.GetInt64();
                            return true;
                        }
                    }

                    throw new Exception("Token initialization failed: Missing token or expire time in response");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Token initialization failed: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 设置请求路径
        /// </summary>
        /// <param name="path">请求路径</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Path(string path)
        {
            _path = path.TrimStart('/');
            return this;
        }

        /// <summary>
        /// 设置GET请求参数
        /// </summary>
        /// <param name="params">请求参数</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Params(Dictionary<string, string> @params)
        {
            foreach (var param in @params)
            {
                _queryParams[param.Key] = param.Value;
            }
            return this;
        }

        /// <summary>
        /// 设置POST请求体参数
        /// </summary>
        /// <param name="params">请求体参数</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Body(Dictionary<string, object> @params)
        {
            foreach (var param in @params)
            {
                _bodyParams[param.Key] = param.Value;
            }
            return this;
        }

        /// <summary>
        /// 设置重试次数
        /// </summary>
        /// <param name="times">重试次数</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Retry(int times)
        {
            _retryTimes = Math.Max(0, times);
            return this;
        }

        /// <summary>
        /// 设置请求头
        /// </summary>
        /// <param name="headers">请求头</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Headers(Dictionary<string, string> headers)
        {
            foreach (var header in headers)
            {
                _headers[header.Key] = header.Value;
            }
            return this;
        }

        /// <summary>
        /// 设置超时时间
        /// </summary>
        /// <param name="seconds">超时秒数</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient Timeout(int seconds)
        {
            _timeout = seconds;
            _httpClient.Timeout = TimeSpan.FromSeconds(_timeout);
            return this;
        }

        /// <summary>
        /// 开启参数加密
        /// </summary>
        /// <param name="enable">是否启用</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient EnableParamEncrypt(bool enable = true)
        {
            _encryptParams = enable;
            return this;
        }

        /// <summary>
        /// 开启结果解密
        /// </summary>
        /// <param name="enable">是否启用</param>
        /// <returns>当前实例，支持链式调用</returns>
        public YesapiClient EnableResponseDecrypt(bool enable = true)
        {
            _decryptResponse = enable;
            return this;
        }

        /// <summary>
        /// 执行GET请求
        /// </summary>
        /// <returns>响应结果</returns>
        public async Task<JsonElement> GetAsync()
        {
            return await RequestAsync(HttpMethod.Get);
        }

        /// <summary>
        /// 执行GET请求（同步版本）
        /// </summary>
        /// <returns>响应结果</returns>
        public JsonElement Get()
        {
            return GetAsync().GetAwaiter().GetResult();
        }

        /// <summary>
        /// 执行POST请求
        /// </summary>
        /// <returns>响应结果</returns>
        public async Task<JsonElement> PostAsync()
        {
            return await RequestAsync(HttpMethod.Post);
        }

        /// <summary>
        /// 执行POST请求（同步版本）
        /// </summary>
        /// <returns>响应结果</returns>
        public JsonElement Post()
        {
            return PostAsync().GetAwaiter().GetResult();
        }

        /// <summary>
        /// 执行请求
        /// </summary>
        /// <param name="method">请求方法</param>
        /// <returns>响应结果</returns>
        private async Task<JsonElement> RequestAsync(HttpMethod method)
        {
            int attempts = _retryTimes + 1;
            Exception lastException = null;

            for (int attempt = 1; attempt <= attempts; attempt++)
            {
                try
                {
                    return await ExecuteRequestAsync(method);
                }
                catch (Exception ex)
                {
                    lastException = ex;

                    // 如果是最后一次尝试，抛出异常
                    if (attempt == attempts)
                    {
                        throw new Exception(
                            $"Request failed after {_retryTimes} retries: {ex.Message}",
                            ex
                        );
                    }

                    // 等待一段时间后重试（使用指数退避策略）
                    int waitTime = Math.Min((int)Math.Pow(2, attempt - 1) * 1000, 5000); // 最多等待5秒
                    await Task.Delay(waitTime);
                }
            }

            // 这行代码永远不会执行，但C#编译器需要它
            throw lastException;
        }

        /// <summary>
        /// 执行单次请求
        /// </summary>
        /// <param name="method">请求方法</param>
        /// <returns>响应结果</returns>
        private async Task<JsonElement> ExecuteRequestAsync(HttpMethod method)
        {
            // 检查token是否过期，如果过期则刷新
            if (_tokenExpireAt > 0 && _tokenExpireAt <= DateTimeOffset.UtcNow.ToUnixTimeMilliseconds())
            {
                await InitTokenAsync();
            }

            // 构建URL和查询参数
            var uriBuilder = new UriBuilder($"{_domain}/{_path}");

            if (_queryParams.Count > 0)
            {
                var query = string.Join("&", _queryParams.Select(p => $"{Uri.EscapeDataString(p.Key)}={Uri.EscapeDataString(p.Value)}"));
                uriBuilder.Query = query;
            }

            // 创建请求
            var request = new HttpRequestMessage(method, uriBuilder.Uri);

            // 设置请求头
            foreach (var header in _headers)
            {
                request.Headers.TryAddWithoutValidation(header.Key, header.Value);
            }

            // 如果有访问令牌，添加到请求头
            if (!string.IsNullOrEmpty(_accessToken))
            {
                request.Headers.TryAddWithoutValidation("Access-Token", _accessToken);
            }

            // 处理POST请求体
            if (method == HttpMethod.Post && _bodyParams.Count > 0)
            {
                string postDataString = JsonSerializer.Serialize(_bodyParams);

                // 如果启用了参数加密，加密整个body
                if (_encryptParams)
                {
                    byte[] encryptedData = Encrypt(postDataString);
                    request.Content = new ByteArrayContent(encryptedData);
                    request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                }
                else
                {
                    request.Content = new StringContent(postDataString, Encoding.UTF8, "application/json");
                }
            }

            try
            {
                // 发送请求
                var response = await _httpClient.SendAsync(request);

                // 处理错误
                if ((int)response.StatusCode >= 500)
                {
                    throw new Exception($"Server Error: HTTP {(int)response.StatusCode}");
                }

                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    // Token可能已失效，尝试刷新token并重试请求
                    await InitTokenAsync();
                    return await ExecuteRequestAsync(method);
                }

                // 读取响应内容
                string responseContent = await response.Content.ReadAsStringAsync();

                // 如果启用了结果解密，解密响应中的data字段
                if (_decryptResponse)
                {
                    responseContent = DecryptResponse(responseContent);
                }

                // 解析JSON响应
                try
                {
                    using (JsonDocument document = JsonDocument.Parse(responseContent))
                    {
                        return document.RootElement.Clone();
                    }
                }
                catch (JsonException ex)
                {
                    throw new Exception($"Invalid JSON response: {responseContent}", ex);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Request failed: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 加密数据
        /// </summary>
        /// <param name="data">待加密数据</param>
        /// <returns>加密后的字节数组</returns>
        private byte[] Encrypt(string data)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    
                    // 使用加密密钥的字节作为密钥
                    byte[] keyBytes = Encoding.UTF8.GetBytes(_encryptKey);
                    Array.Resize(ref keyBytes, 32); // 确保密钥长度为32字节（256位）
                    aes.Key = keyBytes;
                    
                    // 使用加密密钥作为IV
                    byte[] ivBytes = Encoding.UTF8.GetBytes(_encryptKey);
                    Array.Resize(ref ivBytes, 16); // 确保IV长度为16字节（128位）
                    aes.IV = ivBytes;

                    // 创建加密器
                    ICryptoTransform encryptor = aes.CreateEncryptor();

                    // 加密数据
                    byte[] dataBytes = Encoding.UTF8.GetBytes(data);
                    using (var msEncrypt = new System.IO.MemoryStream())
                    {
                        using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            csEncrypt.Write(dataBytes, 0, dataBytes.Length);
                            csEncrypt.FlushFinalBlock();
                        }
                        return msEncrypt.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Encryption failed: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 解密JSON响应中的data字段
        /// </summary>
        /// <param name="jsonResponse">包含加密data字段的JSON响应</param>
        /// <returns>解密后的JSON响应</returns>
        private string DecryptResponse(string jsonResponse)
        {
            try
            {
                using (JsonDocument document = JsonDocument.Parse(jsonResponse))
                {
                    var root = document.RootElement;
                    
                    // 如果没有data字段，直接返回原始响应
                    if (!root.TryGetProperty("data", out JsonElement dataElement))
                    {
                        return jsonResponse;
                    }

                    // 获取data字段的字节数组
                    byte[] encryptedData = dataElement.GetBytesFromBase64();
                    
                    // 解密data字段
                    string decryptedData = DecryptBytes(encryptedData);
                    
                    // 创建新的JSON对象，包含解密后的data
                    var resultObj = new Dictionary<string, JsonElement>();
                    foreach (var property in root.EnumerateObject())
                    {
                        if (property.Name != "data")
                        {
                            resultObj[property.Name] = property.Value.Clone();
                        }
                    }
                    
                    // 将解密后的data添加到结果中
                    using (JsonDocument decryptedDoc = JsonDocument.Parse(decryptedData))
                    {
                        var decryptedElement = decryptedDoc.RootElement.Clone();
                        return JsonSerializer.Serialize(new
                        {
                            data = decryptedElement,
                            code = resultObj.ContainsKey("code") ? resultObj["code"].GetInt32() : 0,
                            msg = resultObj.ContainsKey("msg") ? resultObj["msg"].GetString() : "",
                            ret = resultObj.ContainsKey("ret") ? resultObj["ret"].GetInt32() : 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Decryption failed: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 解密字节数组
        /// </summary>
        /// <param name="encryptedData">待解密的字节数组</param>
        /// <returns>解密后的字符串</returns>
        private string DecryptBytes(byte[] encryptedData)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    
                    // 使用加密密钥的字节作为密钥
                    byte[] keyBytes = Encoding.UTF8.GetBytes(_encryptKey);
                    Array.Resize(ref keyBytes, 32); // 确保密钥长度为32字节（256位）
                    aes.Key = keyBytes;
                    
                    // 使用加密密钥作为IV
                    byte[] ivBytes = Encoding.UTF8.GetBytes(_encryptKey);
                    Array.Resize(ref ivBytes, 16); // 确保IV长度为16字节（128位）
                    aes.IV = ivBytes;

                    // 创建解密器
                    ICryptoTransform decryptor = aes.CreateDecryptor();

                    // 解密数据
                    using (var msDecrypt = new System.IO.MemoryStream(encryptedData))
                    using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    using (var srDecrypt = new System.IO.StreamReader(csDecrypt))
                    {
                        return srDecrypt.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Decryption failed: {ex.Message}", ex);
            }
        }
    }
}