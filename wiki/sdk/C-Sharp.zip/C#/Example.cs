using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace YesAPI
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                // 创建YesapiClient实例（自动初始化token）
                YesapiClient client = new YesapiClient(
                    "https://your-api-domain.com",  // API域名
                    "your-encrypt-key",             // 加密密钥
                    "your-app-key",                 // 应用key
                    "your-app-secret",              // 应用密钥
                    true                            // 自动初始化token
                );

                // 示例1：简单的GET请求
                var response1 = await client
                    .Path("api/user/info")          // 设置请求路径
                    .Params(new Dictionary<string, string> {  // 设置GET参数
                        { "user_id", "123" }
                    })
                    .GetAsync();                    // 执行GET请求
                Console.WriteLine($"GET Response: {JsonSerializer.Serialize(response1, new JsonSerializerOptions { WriteIndented = true })}");

                // 示例2：带加密的POST请求
                var postData = new Dictionary<string, object>
                {
                    { "name", "John Doe" },
                    { "email", "john@example.com" }
                };

                var response2 = await client
                    .Path("api/user/create")        // 设置请求路径
                    .Body(postData)                 // 设置POST数据
                    .EnableParamEncrypt(true)       // 启用参数加密
                    .EnableResponseDecrypt(true)    // 启用响应解密
                    .Retry(3)                       // 设置重试次数
                    .Timeout(60)                    // 设置超时时间（秒）
                    .Headers(new Dictionary<string, string> {  // 设置自定义请求头
                        { "X-Custom-Header", "value" }
                    })
                    .PostAsync();                   // 执行POST请求
                Console.WriteLine($"POST Response: {JsonSerializer.Serialize(response2, new JsonSerializerOptions { WriteIndented = true })}");

                // 同步版本示例
                var response3 = client
                    .Path("api/user/list")
                    .Get();  // 使用同步方法
                Console.WriteLine($"Sync GET Response: {JsonSerializer.Serialize(response3, new JsonSerializerOptions { WriteIndented = true })}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Error: {ex.InnerException.Message}");
                }
            }
        }
    }
}
