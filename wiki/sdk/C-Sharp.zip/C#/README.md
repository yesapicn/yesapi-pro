# YesAPI C# SDK

这是 YesAPI 的 C# 版本 SDK，提供了与服务端 API 交互的简单方式。

## 功能特点

- 支持链式操作
- 提供 GET 和 POST 请求能力
- 支持参数加密和结果解密
- 支持请求头设置
- 支持超时设置
- 支持重试机制
- 支持访问令牌自动初始化和刷新
- 支持异步和同步操作

## 环境要求

- .NET Standard 2.1 或更高版本
- .NET Core 3.1 或更高版本
- .NET 5.0 或更高版本

## 安装

1. 克隆代码到本地
2. 进入项目目录
3. 执行以下命令构建项目：

```bash
cd yesapi-java-sdk/C#
dotnet build
```

或者，您可以将项目添加到您的解决方案中：

```bash
dotnet add reference path/to/YesapiClient.csproj
```

## 使用示例

### 异步方式（推荐）

```csharp
// 创建 YesapiClient 实例（自动初始化 token）
YesapiClient client = new YesapiClient(
    "https://your-api-domain.com",  // API域名
    "your-encrypt-key",             // 加密密钥
    "your-app-key",                 // 应用key
    "your-app-secret",              // 应用密钥
    true                            // 自动初始化token
);

// 执行 GET 请求
var response = await client
    .Path("api/user/info")          // 设置请求路径
    .Params(new Dictionary<string, string> {  // 设置GET参数
        { "user_id", "123" }
    })
    .GetAsync();                    // 执行GET请求

// 执行带加密的 POST 请求
var postData = new Dictionary<string, object>
{
    { "name", "John Doe" },
    { "email", "john@example.com" }
};

var response = await client
    .Path("api/user/create")        // 设置请求路径
    .Body(postData)                 // 设置POST数据
    .EnableParamEncrypt(true)       // 启用参数加密
    .EnableResponseDecrypt(true)    // 启用响应解密
    .Retry(3)                       // 设置重试次数
    .Timeout(60)                    // 设置超时时间（秒）
    .Headers(new Dictionary<string, string> {  // 设置自定义请求头
        { "X-Custom-Header", "value" }
    })
    .PostAsync();                   // 执行POST请求
```

### 同步方式

```csharp
// 执行 GET 请求
var response = client
    .Path("api/user/info")
    .Params(new Dictionary<string, string> {
        { "user_id", "123" }
    })
    .Get();  // 使用同步方法

// 执行 POST 请求
var response = client
    .Path("api/user/create")
    .Body(postData)
    .Post();  // 使用同步方法
```

## 主要方法

- `Path(string path)` - 设置请求路径
- `Params(Dictionary<string, string> params)` - 设置 GET 请求参数
- `Body(Dictionary<string, object> params)` - 设置 POST 请求体参数
- `Retry(int times)` - 设置重试次数
- `Headers(Dictionary<string, string> headers)` - 设置请求头
- `Timeout(int seconds)` - 设置超时时间
- `EnableParamEncrypt(bool enable)` - 开启/关闭参数加密
- `EnableResponseDecrypt(bool enable)` - 开启/关闭结果解密
- `GetAsync()` - 异步执行 GET 请求
- `Get()` - 同步执行 GET 请求
- `PostAsync()` - 异步执行 POST 请求
- `Post()` - 同步执行 POST 请求
- `InitTokenAsync()` - 初始化访问令牌

## 错误处理

SDK 使用异常机制处理错误。所有的错误都会抛出 Exception，包含详细的错误信息。建议使用 try-catch 块来处理可能的异常：

```csharp
try
{
    var response = await client.Path("api/user/info").GetAsync();
    // 处理响应...
}
catch (Exception ex)
{
    // 处理错误...
    Console.WriteLine($"Error: {ex.Message}");
    if (ex.InnerException != null)
    {
        Console.WriteLine($"Inner Error: {ex.InnerException.Message}");
    }
}
```

## 注意事项

1. 确保在使用前正确设置 API 域名、加密密钥、应用 key 和应用密钥
2. 如果需要使用加密功能，请确保加密密钥正确
3. 建议在生产环境中适当设置重试次数和超时时间
4. 访问令牌会自动管理，包括初始化和刷新，无需手动处理
5. 在 ASP.NET Core 应用中，建议将 YesapiClient 注册为单例服务
6. 推荐使用异步方法（GetAsync/PostAsync）以提高应用性能
